KAHANEE WEBSITE

1. Open index.html in any browser to preview.
2. To publish free:
   - Netlify Drop: drag the kahanee-website folder to Netlify Drop.
   - GitHub Pages: upload index.html to a repository and enable Pages.
   - Cloudflare Pages: upload the static site.
3. Replace gallery colour panels with your real restaurant photos when ready.
4. Update menu prices/text directly inside index.html.
5. Current contact number: 8529919562
6. Current address: C-1/A, Nokha House, Bani Park, Jaipur, Rajasthan
7. Instagram: @kahaneejaipur
